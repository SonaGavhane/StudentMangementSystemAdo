﻿namespace Student_Management
{
    partial class InsertRecords
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.textCourse = new System.Windows.Forms.TextBox();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.txtID = new System.Windows.Forms.NumericUpDown();
            this.txtm1 = new System.Windows.Forms.NumericUpDown();
            this.txtm2 = new System.Windows.Forms.NumericUpDown();
            this.txtm3 = new System.Windows.Forms.NumericUpDown();
            this.textfee = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.txtID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtm1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtm2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtm3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textfee)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(92, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(92, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(89, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "COURSE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(92, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "EMAIL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label5.Location = new System.Drawing.Point(96, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "FEES";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(96, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "MARKS";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(226, 112);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(126, 20);
            this.textName.TabIndex = 7;
            // 
            // textCourse
            // 
            this.textCourse.Location = new System.Drawing.Point(226, 153);
            this.textCourse.Name = "textCourse";
            this.textCourse.Size = new System.Drawing.Size(126, 20);
            this.textCourse.TabIndex = 8;
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(226, 188);
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(126, 20);
            this.textEmail.TabIndex = 9;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnsubmit.Location = new System.Drawing.Point(249, 298);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 23);
            this.btnsubmit.TabIndex = 15;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(226, 69);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(120, 20);
            this.txtID.TabIndex = 16;
            // 
            // txtm1
            // 
            this.txtm1.Location = new System.Drawing.Point(199, 272);
            this.txtm1.Name = "txtm1";
            this.txtm1.Size = new System.Drawing.Size(44, 20);
            this.txtm1.TabIndex = 18;
            // 
            // txtm2
            // 
            this.txtm2.Location = new System.Drawing.Point(249, 272);
            this.txtm2.Name = "txtm2";
            this.txtm2.Size = new System.Drawing.Size(44, 20);
            this.txtm2.TabIndex = 19;
            // 
            // txtm3
            // 
            this.txtm3.Location = new System.Drawing.Point(302, 272);
            this.txtm3.Name = "txtm3";
            this.txtm3.Size = new System.Drawing.Size(44, 20);
            this.txtm3.TabIndex = 20;
            // 
            // textfee
            // 
            this.textfee.Location = new System.Drawing.Point(226, 228);
            this.textfee.Name = "textfee";
            this.textfee.Size = new System.Drawing.Size(120, 20);
            this.textfee.TabIndex = 21;
            // 
            // InsertRecords
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 335);
            this.Controls.Add(this.textfee);
            this.Controls.Add(this.txtm3);
            this.Controls.Add(this.txtm2);
            this.Controls.Add(this.txtm1);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.textCourse);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "InsertRecords";
            this.Text = "InsertRecords";
            this.Load += new System.EventHandler(this.InsertRecords_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtm1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtm2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtm3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textfee)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textCourse;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.NumericUpDown txtID;
        private System.Windows.Forms.NumericUpDown txtm1;
        private System.Windows.Forms.NumericUpDown txtm2;
        private System.Windows.Forms.NumericUpDown txtm3;
        private System.Windows.Forms.NumericUpDown textfee;
    }
}