﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management
{
    public partial class DeleteRecords : Form
    {
        public Student stu1;
        public DeleteRecords()
        {
            InitializeComponent();
            stu1 = new Student();
        }

        private void DeleteRecords_Load(object sender, EventArgs e)
        {
           
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            stu1.rec = int.Parse(txt1.Text);
            Form1 ob = new Form1(stu1,stu1.rec);
            ob.Show();
            this.Hide();
        }
    }
}
