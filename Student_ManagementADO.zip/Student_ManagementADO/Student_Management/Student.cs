﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Management
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
        public string Email { get; set; }
        public float Fees { get; set; }
        public int[] Marks { get; set; }
        public Student()
        {
            Marks = new int[3];
        }
        public string Data_string()
        {
            string mydata = "";
            mydata= "ID=" + Id;
            mydata+= "|Name=" + Name;
            mydata+= "|Course=" + Course;
            mydata+= "|Email=" + Email;
            mydata+= "|Fees=" + Fees.ToString();
            mydata+= "|M1=" + Marks[0].ToString();
            mydata+= "|M2=" + Marks[1].ToString();
            mydata+= "|M3=" + Marks[2].ToString();
            return mydata;
        }
        public int rec { get; set; }
        
    }

}