﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management
{
    public partial class Form1 : Form
    {
        public static List<Student> stulist=new List<Student>();
        public Form1()
        {
            InitializeComponent();
           
        }
        public Form1(Student ob)
        {
            InitializeComponent();
            stulist.Add(ob);
            

        }
        public Form1(Student ob,int rec)
       {
       InitializeComponent();
        stulist.RemoveAt(ob.rec);
            
       }

        private void btninsert_Click_1(object sender, EventArgs e)
        {
            InsertRecords ob = new InsertRecords();
            ob.Show();
            this.Hide();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            Show_details ob = new Show_details();
            ob.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btndel_Click(object sender, EventArgs e)
        {
            DeleteRecords ob = new DeleteRecords();
            ob.Show();
            this.Hide();
        }
    }
}
