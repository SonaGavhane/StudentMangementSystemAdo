﻿namespace Student_Management
{
    partial class Show_details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.liststudent = new System.Windows.Forms.ListView();
            this.btn1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // liststudent
            // 
            this.liststudent.AutoArrange = false;
            this.liststudent.HideSelection = false;
            this.liststudent.Location = new System.Drawing.Point(53, 89);
            this.liststudent.Name = "liststudent";
            this.liststudent.Size = new System.Drawing.Size(564, 259);
            this.liststudent.TabIndex = 0;
            this.liststudent.UseCompatibleStateImageBehavior = false;
            this.liststudent.View = System.Windows.Forms.View.List;
            // 
            // btn1
            // 
            this.btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(681, 169);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 1;
            this.btn1.Text = "SUBMIT";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // Show_details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 421);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.liststudent);
            this.Name = "Show_details";
            this.Text = "Show_details";
            this.Load += new System.EventHandler(this.Show_details_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView liststudent;
        private System.Windows.Forms.Button btn1;
    }
}