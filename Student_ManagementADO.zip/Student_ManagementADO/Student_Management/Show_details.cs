﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management
{
    public partial class Show_details : Form
    {
        public Show_details()
        {
            InitializeComponent();
        }

        private void Show_details_Load(object sender, EventArgs e)
        {
            foreach (var ob in Form1.stulist)
            {
                liststudent.Items.Add(ob.Data_string());
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}
