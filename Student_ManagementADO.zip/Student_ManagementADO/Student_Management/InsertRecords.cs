﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Management
{
    public partial class InsertRecords : Form
    {
        public Student stu;
        public InsertRecords()
        {
            InitializeComponent();
            stu = new Student();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            stu.Id =int.Parse(txtID.Value.ToString());
            stu.Name = textName.Text;
            stu.Email = textEmail.Text;
            stu.Course = textCourse.Text;
            stu.Fees = float.Parse(textfee.Value.ToString());
            stu.Marks[0] = int.Parse(txtm1.Value.ToString());
            stu.Marks[1] = int.Parse(txtm2.Value.ToString());
            stu.Marks[2] = int.Parse(txtm3.Value.ToString());
            
            Form1 ob = new Form1(stu);
            ob.Show();
            this.Hide();
        }

        private void InsertRecords_Load(object sender, EventArgs e)
        {

        }
    }
}
